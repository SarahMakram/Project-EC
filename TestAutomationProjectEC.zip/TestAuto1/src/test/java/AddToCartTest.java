import com.github.dockerjava.core.dockerfile.DockerfileStatement;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AddToCartTest extends TestBase {
    AddToCart addItemToCart;
    AddToCart add;
    String QEx = "1";
    String QExpected = "3";



    @Test (priority = 2)
    public void addItemToCart()
    {
        addItemToCart = new AddToCart(driver);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)", "");
       String QActual = addItemToCart.addItem(QExpected);
        Assert.assertEquals(QActual,QExpected);
    }

    @Test (priority = 1)
    public void check()
    {
        addItemToCart = new AddToCart(driver);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)", "");

        String QActual = addItemToCart.addItem(QEx);
        Assert.assertEquals(QActual,QEx);
    }

}
