import net.bytebuddy.build.Plugin;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SearchTest extends TestBase{
    SearchPage search;

    @Test (priority = 2)
    public void InvalidSearch()
    {

        search = new SearchPage(driver);
        search.Search("Top");
        String expected = "SEARCHED PRODUCTS";
        String actual = driver.findElement(By.xpath("//h2[@class='title text-center']")).getText();
        Assert.assertTrue(actual.contains(expected));


    }

   @Test (priority = 1)
    public void ValidSearch()
    {
        search = new SearchPage(driver);
        search.searchItem("Dress");
        Assert.assertTrue(driver.findElement(By.xpath("//a[@href='/product_details/3']")).getText().contains("View Product"));
    }


}
