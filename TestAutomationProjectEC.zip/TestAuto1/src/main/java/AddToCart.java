import dev.failsafe.internal.util.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.time.Duration;

public class AddToCart extends PageBase {

    public AddToCart (WebDriver driver) {
        super(driver);
    }

    @FindBy (xpath = "(//a[@href='/product_details/1'])[1]")
    WebElement viewProduct;

    @FindBy (xpath = "//input[@type='number']")
    WebElement quantity;

    @FindBy (xpath = "//button[@type='button']")
    WebElement addToCart;

    @FindBy (xpath = "//button[@data-dismiss='modal']")
    WebElement continueShoppingButton;


    @FindBy (xpath = "(//a[@href='/view_cart'])[1]")
    WebElement Cart;

    @FindBy (xpath = "//button[@class='disabled']")
    WebElement QuantityCart;



    @FindBy (xpath = "//a[@class='cart_quantity_delete']")
    WebElement deleteItem;

     public String  addItem(String QExpected)
     {

         viewProduct.click();
         quantity.clear();

         quantity.sendKeys(QExpected);
         addToCart.click();
         driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
         continueShoppingButton.click();
         Cart.click();

         return   QuantityCart.getText();

     }



}
