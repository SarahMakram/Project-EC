import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.security.Key;

public class SearchPage extends PageBase{
     public SearchPage(WebDriver driver) {
        super(driver);
    }

   @FindBy (xpath = "//input[@type='text']")
     WebElement searchBox;

     @FindBy (xpath = "//button[@type='button']")
    WebElement searchButton;


     public void searchItem( String item)
     {
         searchBox.sendKeys(item);
         searchButton.click();

     }
     public void Search(String item)
     {
         searchBox.clear();
         searchBox.sendKeys(item);
         searchBox.sendKeys(Keys.ENTER);
     }

}
